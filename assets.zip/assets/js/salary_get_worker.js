$(document).ready(function () {
  const WORKER_SALARY_API_URL = `${API_URL}/staff`;
  const token = getToken();

  if (!token) {
    Swal.fire({
      icon: "error",
      title: "Authentication Required!",
      text: "Please login first before proceeding.",
      confirmButtonText: "Log in now."
    }).then(() => {
      window.location.href = "/pages/log-in.html";
    });
    return;
  }

  const headers = {
    "Authorization": "Bearer " + token,
    "Content-Type": "application/json",
    "Accept": "application/json"
  };

  // --- URL sync for Worker/Staff toggle ---
  function showEmployeeType(type, push) {
    if (type === 'staff') {
      // Show staff section
      $('#staffSection').removeClass('d-none');
      $('#workerSection').addClass('d-none');
      $('#staff').prop('checked', true);

      if (typeof fetchUsers === 'function') fetchUsers(1);
    } else {
      // Show worker section
      $('#workerSection').removeClass('d-none');
      $('#staffSection').addClass('d-none');
      $('#worker').prop('checked', true);

      if (typeof fetchWorkers === 'function') fetchWorkers(1);
    }

    const url = '?employee=' + type;
    if (push) {
      history.pushState({ employee: type }, '', url);
    } else {
      history.replaceState({ employee: type }, '', url);
    }
  }


  // Initial state from URL
  const params = new URLSearchParams(window.location.search);
  const initialEmployee = params.get('employee') === 'staff' ? 'staff' : 'worker';
  showEmployeeType(initialEmployee, false);

  // Toggle by radio button
  $('#worker').on('change', function () {
    if ($(this).is(':checked')) showEmployeeType('worker', true);
  });
  $('#staff').on('change', function () {
    if ($(this).is(':checked')) showEmployeeType('staff', true);
  });

  // Handle back/forward
  window.addEventListener('popstate', function (ev) {
    const p = new URLSearchParams(window.location.search).get('employee');
    showEmployeeType(p === 'staff' ? 'staff' : 'worker', false);
  });

  let currentPage = 1;
  let lastPage = 1;

  function fetchWorkers(page = 1) {
    // Only fetch if Worker section is visible
    if ($('#workerList').hasClass('d-none')) return;

    const searchInput = $("#searchWorker").val().trim();
    const params = {
      per_page: 15,
      page: page,
      ...(searchInput ? { search: searchInput } : {})
    };

    // Show skeleton loaders
    const skeletonHtml = Array(6).fill(0).map(() => `
      <div class="col-12 col-sm-6 col-md-4">
        <div class="card h-100 shadow-sm">
          <div class="card-body d-flex gap-3 align-items-center">
            <div class="skeleton skeleton-circle" style="width: 64px; height: 64px;"></div>
            <div class="flex-grow-1">
              <div class="skeleton skeleton-text" style="width: 60%; height: 20px; margin-bottom: 8px;"></div>
              <div class="skeleton skeleton-text" style="width: 40%; height: 16px;"></div>
            </div>
            <div class="skeleton skeleton-button" style="width: 40px; height: 32px;"></div>
          </div>
        </div>
      </div>
    `).join('');
    $("#workerList .row").html(skeletonHtml);

    $.ajax({
      url: WORKER_SALARY_API_URL,
      method: "GET",
      headers: headers,
      data: params,
      success: function (response) {
        if (response && response.success && Array.isArray(response.data)) {
          renderWorker(response.data);
          currentPage = response.meta?.current_page || 1;
          lastPage = response.meta?.last_page || 1;
          renderPagination();
        } else {
          $("#workerList .row").html('<div class="col-12 text-center text-muted">No workers found</div>');
          $("#workerPagination").remove();
        }
      },
      error: function (xhr) {
        console.error("Failed to load workers:", xhr.responseText);
        $("#workerList .row").html('<div class="col-12 text-center text-danger">Error loading workers</div>');
        $("#workerPagination").remove();
      }
    });
  }

  function renderWorker(workers) {
    const $row = $("#workerList .row");
    $row.empty();

    if (!workers.length) {
      $row.append('<div class="col-12 text-center text-muted">No workers found</div>');
      return;
    }

    workers.forEach(worker => {
      const workerId = worker.id || "";
      const workerName = worker.staff_fullname || "Unknown";
      const workerAvatar = worker.staff_img
        ? (worker.staff_img.startsWith("http") ? worker.staff_img : `${STORAGE_DOMAIN}${worker.staff_img}`)
        : "https://via.placeholder.com/64";

      // Safely access nested base_salary property
      let workerBaseSalary = "Not set";
      if (worker.base_salary && worker.base_salary.base_salary != null) {
        workerBaseSalary = worker.base_salary.base_salary;
      }

      const $col = $("<div>").addClass("col-12 col-sm-6 col-md-4");
      const $card = $(`
        <div class="card h-100 shadow-sm">
          <div class="card-body d-flex gap-3 align-items-center">
            <img src="${workerAvatar}" alt="${workerName}" class="rounded-circle" width="64" height="64">
            <div class="flex-grow-1">
              <h6 class="mb-1">${workerName}</h6>
              <small class="text-muted d-block">Base Salary: <strong>${workerBaseSalary}</strong></small>
            </div>
            <div class="d-flex flex-column ms-auto">
              <a href="../pages/manage-payment-rate-edit-salary-worker.html?id=${encodeURIComponent(workerId)}" 
                 class="btn btn-sm btn-outline-success" title="Edit base salary">
                 <i class="bi bi-pencil-fill"></i>
              </a>
            </div>
          </div>
        </div>
      `);
      $col.append($card);
      $row.append($col);
    });
  }

  function renderPagination() {
    $("#workerPagination").remove();
    if (lastPage <= 1) return;

    const $container = $("#workerList");
    const $pagination = $('<div id="workerPagination" class="mt-3 text-center"></div>');

    // Previous button
    const $prev = $('<button class="btn btn-sm btn-outline-success mx-1"><i class="bi bi-chevron-left"></i></button>');
    $prev.prop("disabled", currentPage === 1);
    $prev.on("click", () => fetchWorkers(currentPage - 1));
    $pagination.append($prev);

    // Smart page buttons with ellipsis (max 7 buttons)
    let pages = [];
    if (lastPage <= 7) {
      // Show all pages if 7 or fewer
      pages = Array.from({ length: lastPage }, (_, i) => i + 1);
    } else {
      // Smart ellipsis logic
      if (currentPage <= 4) {
        // Near start: [1] [2] [3] [4] [5] [...] [last]
        pages = [1, 2, 3, 4, 5, '...', lastPage];
      } else if (currentPage >= lastPage - 3) {
        // Near end: [1] [...] [last-4] [last-3] [last-2] [last-1] [last]
        pages = [1, '...', lastPage - 4, lastPage - 3, lastPage - 2, lastPage - 1, lastPage];
      } else {
        // Middle: [1] [...] [current-1] [current] [current+1] [...] [last]
        pages = [1, '...', currentPage - 1, currentPage, currentPage + 1, '...', lastPage];
      }
    }

    // Render page buttons
    pages.forEach((page) => {
      if (page === '...') {
        // Ellipsis (non-clickable)
        const $ellipsis = $('<span class="btn btn-sm btn-outline-success mx-1 disabled">...</span>');
        $pagination.append($ellipsis);
      } else {
        // Page button
        const $btn = $(`<button class="btn btn-sm mx-1">${page}</button>`);
        $btn.addClass(page === currentPage ? "btn-success" : "btn-outline-success");
        $btn.on("click", () => fetchWorkers(page));
        $pagination.append($btn);
      }
    });

    // Next button
    const $next = $('<button class="btn btn-sm btn-outline-success mx-1"><i class="bi bi-chevron-right"></i></button>');
    $next.prop("disabled", currentPage === lastPage);
    $next.on("click", () => fetchWorkers(currentPage + 1));
    $pagination.append($next);

    $container.append($pagination);
  }

  // Search input
  $("#searchWorker").on("input", function () {
    const value = $(this).val().trim();
    // Show/hide clear button
    if (value.length > 0) {
      $("#clearSearchWorker").show();
    } else {
      $("#clearSearchWorker").hide();
    }
    fetchWorkers(1);
  });

  // Clear search button
  $("#clearSearchWorker").on("click", function () {
    $("#searchWorker").val("");
    $(this).hide();
    fetchWorkers(1);
  });

  // Initial fetch
  fetchWorkers();

  // Re-fetch when Worker section becomes visible
  $('input[name="employeeType"]').on("change", () => fetchWorkers(1));
});

