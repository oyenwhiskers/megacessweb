const PAYMENT_RATES_API_URL = `${API_URL}/payment-rates`;

/* -------------------- Token Helper -------------------- */
function getToken() {
  const keys = ['authToken', 'auth_token', 'token', 'access_token'];
  for (const k of keys) {
    const v = localStorage.getItem(k) || sessionStorage.getItem(k);
    if (v) return v;
  }
  console.warn(" No token found in storage");
  return null;
}

/* -------------------- Fetch Payment Rates -------------------- */
async function getPaymentRates() {
  const token = getToken();
  if (!token) {
    console.error("Token not found. Please ensure user is authenticated.");
    Swal.fire({
      icon: "error",
      title: "Authentication Required!",
      text: "Please login first before proceeding.",
      confirmButtonText: "Log in now."
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = "../pages/log-in.html"
      }
    });
    return;
  }

  // Show skeleton loaders
  const $list = $('#taskList');
  const skeletonHtml = Array(5).fill(0).map(() => `
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <div class="skeleton skeleton-text" style="width: 60%; height: 18px;"></div>
      <div class="skeleton skeleton-badge" style="width: 80px; height: 24px; border-radius: 12px;"></div>
    </li>
  `).join('');
  $list.html(skeletonHtml);
  $('#workSection .task-editor .card-body').html('<div class="text-center py-5"><div class="skeleton skeleton-text mx-auto" style="width: 80%; height: 200px;"></div></div>');

  try {
    const res = await fetch(PAYMENT_RATES_API_URL, {
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json",
        "Content-Type": "application/json"
      }
    });

    if (!res.ok) throw new Error(`Failed to fetch (${res.status})`);

    const json = await res.json();
    if (json.success && Array.isArray(json.data)) {
      renderTaskList(json.data);
    } else {
      console.warn(" Invalid data format from API");
    }
  } catch (err) {
    console.error(" Error fetching payment rates:", err);
  }
}

/* -------------------- Render Left Panel (Task List) -------------------- */
function renderTaskList(tasks) {
  const $list = $('#taskList');
  if ($list.length === 0) {
    console.error(" Missing #taskList container in HTML");
    return;
  }

  $list.empty();

  if (!tasks || tasks.length === 0) {
    $list.append('<li class="list-group-item text-center text-muted">No tasks found</li>');
    return;
  }

  tasks.forEach((task, index) => {
    const activeClass = index === 0 ? 'active' : '';
    const firstCategory = task.categories?.[0];
    const categoryCount = task.categories?.length || 0;

    const item = `
      <li class="list-group-item d-flex justify-content-between align-items-center ${activeClass}" 
          data-id="${task.id}">
        <div>
          <span>${task.task_name}</span>
        </div>
        <span class="badge bg-secondary ms-2" style="font-size: 0.75rem;">${categoryCount} 
        ${categoryCount === 1 ? 'category' : 'categories'}</span>
      </li>
    `;

    $list.append(item);
  });

  // Load first task details
  renderTaskEditor(tasks[0]);

  // Handle click
  $list.off('click', 'li').on('click', 'li', function () {
    $list.find('li').removeClass('active');
    $(this).addClass('active');
    const id = $(this).data('id');
    const selected = tasks.find(t => t.id === id);
    if (selected) renderTaskEditor(selected);
  });
}

/* -------------------- Render Right Panel (Task Editor/Preview + Edit Mode) -------------------- */
function renderTaskEditor(task) {
  const $editor = $('#workSection .task-editor .card-body');
  if (!$editor.length || !task) return;

  let categoryHtml = '';
  if (Array.isArray(task.categories)) {
    categoryHtml = task.categories.map((c, i) => {
      // --- FIX: extract condition values from c.conditions (backend format) ---
      const cond = c.conditions || {};
      // detect first min_/max_ key to derive type suffix, Option A: map to suffix
      let condType = '';
      for (const key of Object.keys(cond)) {
        if (key.startsWith('min_')) { condType = key.replace(/^min_/, ''); break; }
        if (key.startsWith('max_')) { condType = key.replace(/^max_/, ''); break; }
      }
      const minVal = condType ? (cond[`min_${condType}`] ?? '') : '';
      const maxVal = condType ? (cond[`max_${condType}`] ?? '') : '';
      const condUnit = (cond && cond.unit) ? cond.unit : (c.unit || '');

      return `
      <div class="border rounded p-3 mb-3 category-block" 
           data-index="${i}" 
           data-category='${JSON.stringify(c)}'>

        <!-- Category Header -->
        <div class="mb-2 small text-muted">
          <strong>Category ID:</strong> ${c.id || 'N/A'}
        </div>

        <!-- Row 0: Category Name -->
        <div class="row">
          <div class="col-md-10 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Name to identify this payment category">
              Category Name <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="text" class="form-control category-name" value="${c.category_name || ''}" disabled>
          </div>
          <div class="col-md-2 mb-2 d-flex align-items-end">
            <button class="btn btn-sm btn-danger remove-category-btn w-100 mb-1" type="button" title="Remove category">
              <i class="bi bi-trash"></i> Remove
            </button>
          </div>
        </div>

        <!-- Row 1: Rate and Unit -->
        <div class="row">
          <div class="col-md-6 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="The payment amount for this category">
              Rate <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="number" class="form-control category-rate" value="${c.rate ?? ''}" disabled>
          </div>
          <div class="col-md-6 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Unit of measurement (e.g., per kg, per hour, per tree)">
              Unit <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="text" class="form-control category-unit" value="${c.unit ?? ''}" disabled>
          </div>
        </div>

        <!-- Row 2: Condition Fields (Type, Min, Max, Condition Unit) -->
        <div class="row">
          <div class="col-md-3 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Type of condition (e.g., weight, quantity, area, fruit)">
              Type <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <!-- keep as a text input (you requested free-text type) -->
            <input type="text" class="form-control category-type" value="${condType || ''}" disabled>
          </div>
          <div class="col-md-3 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Minimum value for this condition range">
              Min Value <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="number" class="form-control category-min" value="${minVal}" disabled>
          </div>
          <div class="col-md-3 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Maximum value for this condition range">
              Max Value <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="number" class="form-control category-max" value="${maxVal}" disabled>
          </div>
          <div class="col-md-3 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Unit for the condition values (e.g., kg, pcs, m²)">
              Condition Unit <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="text" class="form-control category-condition-unit" value="${condUnit}" disabled>
          </div>
        </div>

        <!-- Row 3: Display Order -->
        <div class="row">
          <div class="col-md-12 mb-2">
            <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Order in which this category appears in the list (starts with 0,1,2...)">
              Display Order <i class="bi bi-info-circle text-muted ms-1"></i>
            </label>
            <input type="number" class="form-control category-order" value="${c.display_order ?? ''}" disabled>
          </div>
        </div>
      </div>
    `}).join('');
  }

  const html = `
    <div>
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h5 class="mb-1">Edit Payment Rate</h5>
          <div class="small text-muted">Payment Rate ID: <strong>${task.id || 'N/A'}</strong></div>
        </div>
        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-danger py-1 px-3" id="deleteBtn">
            <i class="bi bi-trash-fill"></i> Delete
            </button>
          <button class="btn btn-sm btn-secondary py-1 px-3" id="editToggleBtn"> 
            <i class="bi bi-pencil-square"></i> Edit
            </button>
        </div>

      </div>

      <div class="mb-3">
        <label class="form-label fw-semibold" data-bs-toggle="tooltip" data-bs-placement="top" title="Name of the work task or job type">
          Task Name <i class="bi bi-info-circle text-muted ms-1"></i>
        </label>
        <input type="text" class="form-control" id="taskName" value="${task.task_name || ''}" readonly>
      </div>

      <!-- <div class="form-check form-switch mb-3">
        <input class="form-check-input" type="checkbox" id="isActive" ${task.is_active ? 'checked' : ''} disabled>
        <label class="form-check-label" for="isActive">Active</label>
      </div> -->

      <div class="mb-3">
        <label class="form-label fw-semibold" data-bs-toggle="tooltip" data-bs-placement="top" title="Additional details about this payment rate">
          Description <i class="bi bi-info-circle text-muted ms-1"></i>
        </label>
        <textarea class="form-control" id="description" rows="3" readonly>${task.description || ''}</textarea>
      </div>

      <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <label class="form-label fw-bold mb-0">Categories & Rates</label>
          <button class="btn btn-sm btn-success fw-semibold py-1 px-3 d-none" id="addCategoryBtn" type="button">
            <i class="bi bi-plus-circle me-1"></i> Add Category
          </button>
        </div>
        <hr>
        ${categoryHtml || '<p class="text-muted">No categories defined</p>'}
      </div>
      <div class="text-end">
        <button class="btn btn-success d-none" id="saveChangesBtn">Save Changes</button>
      </div>
    </div>
  `;

  $editor.html(html);

  // Delete button
  $('#deleteBtn').off('click').on('click', function () {
    deletePaymentRate(task.id);
  });

  // Toggle edit mode (keep your original behavior exactly)
  $('#editToggleBtn').off('click').on('click', function () {
    const isEditing = $(this).data('editing') || false;

    if (!isEditing) {
      $(this).text('Cancel').data('editing', true);
      $('#saveChangesBtn').removeClass('d-none');
      $('#addCategoryBtn').removeClass('d-none');
      $editor.find('input, textarea').removeAttr('readonly').removeAttr('disabled');
    } else {
      $(this).text('Edit').data('editing', false);
      $('#saveChangesBtn').addClass('d-none');
      $('#addCategoryBtn').addClass('d-none');
      $editor.find('input, textarea').attr('readonly', true);
      $editor.find('input[type="checkbox"], input[type="number"], input[type="text"]').attr('disabled', true);
      renderTaskEditor(task);
    }
  });

  // Save button wiring with validation
  $('#saveChangesBtn').off('click').on('click', async function () {
    // Validate categories first
    if (!validateCategories()) {
      return; // Stop if validation fails
    }

    const updatedData = collectFormData(task.id);
    await updatePaymentRate(task.id, updatedData);
  });

  // Initialize Bootstrap tooltips after DOM is updated
  setTimeout(() => {
    // Dispose of any existing tooltips first
    $editor.find('[data-bs-toggle="tooltip"]').each(function () {
      const existingTooltip = bootstrap.Tooltip.getInstance(this);
      if (existingTooltip) {
        existingTooltip.dispose();
      }
    });

    // Initialize new tooltips
    $editor.find('[data-bs-toggle="tooltip"]').each(function () {
      new bootstrap.Tooltip(this, {
        trigger: 'hover'
      });
    });
  }, 100);

  // Add Category trigger
  $('#addCategoryBtn').off('click').on('click', function () {
    // Automatically enable edit mode if not already editing
    const isEditing = $('#editToggleBtn').data('editing') || false;
    if (!isEditing) {
      $('#editToggleBtn').click(); // Trigger edit mode
    }

    openAddCategoryModal((newCat) => {
      appendNewCategoryBlock(newCat);
      // Auto-save after adding category
      setTimeout(async () => {
        if (validateCategories()) {
          const updatedData = collectFormData(task.id);
          await updatePaymentRate(task.id, updatedData);
        }
      }, 500); // Small delay to ensure DOM is updated
    });
  });

  // Remove Category button handler (using event delegation for dynamically added elements)
  $editor.off('click', '.remove-category-btn').on('click', '.remove-category-btn', function () {
    const $block = $(this).closest('.category-block');
    const categoryData = JSON.parse($block.attr('data-category') || '{}');
    const categoryName = categoryData.category_name || 'this category';
    const categoryId = categoryData.id;

    // If category has an ID, it exists in backend - call API to delete
    if (categoryId) {
      if (typeof deletePaymentRateCategory === 'function') {
        deletePaymentRateCategory(task.id, categoryId);
      } else {
        console.error('deletePaymentRateCategory function not found');
      }
    } else {
      // If no ID, it's a newly added category not yet saved - just remove from UI
      Swal.fire({
        title: 'Remove Category?',
        text: `Are you sure you want to remove "${categoryName}"? This action cannot be undone.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, remove it',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          $block.remove();
          Swal.fire({
            icon: 'success',
            title: 'Removed!',
            text: 'Category has been removed from the form.',
            timer: 1500,
            showConfirmButton: false
          });
        }
      });
    }
  });
}

/* -------------------- Collect Form Data -------------------- */
function collectFormData(taskId) {
  const data = {
    task_name: $('#taskName').val(),
    description: $('#description').val(),
    is_active: true,
    categories: []
  };

  $('.category-block').each(function () {
    let original = {};
    try {
      original = JSON.parse($(this).attr('data-category') || '{}');
    } catch (e) {
      original = {};
    }

    // read UI fields 
    const catName = $(this).find('.category-name').val()?.trim() || original.category_name || '';
    const rateVal = $(this).find('.category-rate').val();
    const unitVal = $(this).find('.category-unit').val();
    const orderVal = parseInt($(this).find('.category-order').val()) || 0;
    const catKey = original.category_key || catName.toLowerCase().replace(/\s+/g, '_') || '';

    // read the free-text type exactly as the UI provides it
    const type = $(this).find('.category-type').val()?.trim() || '';
    const minRaw = $(this).find('.category-min').val();
    const maxRaw = $(this).find('.category-max').val();
    const condUnit = $(this).find('.category-condition-unit').val()?.trim() || '';

    // Validate: if min or max is provided, type must not be empty
    const hasMinOrMax = (minRaw !== "" && minRaw !== null && typeof minRaw !== 'undefined') ||
      (maxRaw !== "" && maxRaw !== null && typeof maxRaw !== 'undefined');

    if (hasMinOrMax && !type) {
      Swal.fire({
        icon: 'error',
        title: 'Validation Error',
        text: `Category "${catName}" has min/max values but no Condition Type. Please specify the type (e.g., weight, quantity, area).`,
        confirmButtonText: 'OK'
      });
      return false; // Stop processing
    }

    // To build conditions according to:
    // if type === 'weight' -> min_weight, max_weight
    // if type === 'quantity' -> min_quantity, max_quantity
    // if type === 'area' -> min_area, max_area

    let conditions = null;
    if (type) {
      const c = {};
      if (minRaw !== "" && minRaw !== null && typeof minRaw !== 'undefined') {
        const parsed = parseFloat(minRaw);
        if (!Number.isNaN(parsed)) c[`min_${type}`] = parsed;
      }
      if (maxRaw !== "" && maxRaw !== null && typeof maxRaw !== 'undefined') {
        const parsed2 = parseFloat(maxRaw);
        if (!Number.isNaN(parsed2)) c[`max_${type}`] = parsed2;
      }
      if (condUnit) c['unit'] = condUnit;
      if (Object.keys(c).length > 0) conditions = c;
      else conditions = null;
    } else {
      conditions = null;
    }

    const category = {
    id: original.id ?? null,
      payment_rate_id: taskId,
      category_name: catName,
      category_key: catKey,
      rate: rateVal,
      unit: unitVal,
      display_order: orderVal,
      conditions: conditions
    };

    data.categories.push(category);
  });

  return data;
}

/* Validate categories before submission */
function validateCategories() {
  let isValid = true;
  const errors = [];

  $('.category-block').each(function () {
    const catName = $(this).find('strong').first().text().trim() || 'Unnamed Category';
    const type = $(this).find('.category-type').val()?.trim() || '';
    const minRaw = $(this).find('.category-min').val();
    const maxRaw = $(this).find('.category-max').val();

    const hasMinOrMax = (minRaw !== "" && minRaw !== null && typeof minRaw !== 'undefined') ||
      (maxRaw !== "" && maxRaw !== null && typeof maxRaw !== 'undefined');

    if (hasMinOrMax && !type) {
      isValid = false;
      errors.push(`"${catName}" has min/max values but no Condition Type`);
    }
  });

  if (!isValid) {
    Swal.fire({
      icon: 'error',
      title: 'Validation Error',
      html: `<p>Please fix the following issues:</p><ul class="text-start">${errors.map(e => `<li>${e}</li>`).join('')}</ul><p class="mt-3">Condition Type is required when Min or Max values are provided (e.g., weight, quantity, area).</p>`,
      confirmButtonText: 'OK'
    });
  }

  return isValid;
}

/* -------------------- PUT Request (Update Payment Rate) -------------------- */
async function updatePaymentRate(id, bodyData) {
  const token = getToken();
  if (!token) {
    console.error("Token not found. Please ensure user is authenticated.");
    Swal.fire({
      icon: "error",
      title: "Authentication Required!",
      text: "Please login first before proceeding.",
      confirmButtonText: "Log in now."
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = "../pages/log-in.html"
      }
    });
    return;
  }

  try {
    const res = await fetch(`${PAYMENT_RATES_API_URL}/${id}`, {
      method: "PUT",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(bodyData)
    });

    const json = await res.json();

    if (json.success) {
      Swal.fire({
        icon: "success",
        title: "Saved successfully!",
        text: "Payment rate has been updated.",
        timer: 2000,
        timerProgressBar: true,
        showConfirmButton: false
      });
      getPaymentRates(); // reload list
    } else {
      console.warn("Update validation errors:", json.errors);
      Swal.fire({
        icon: "warning",
        title: "Failed to update",
        text: `${json.message}\n\n ${json.errors}`
      });
    }
  } catch (err) {
    console.error("Error updating payment rate:", err);
  }
}

/* -------------------- Add Category Modal -------------------- */
function ensureAddCategoryModalExists() {
  if ($('#addCategoryModal').length) return;

  const modalHtml = `
  <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fw-semibold">Add Category</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form id="addCategoryForm">
            <div class="row">
              <div class="col-12 mb-3">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Name to identify this payment category">
                  Category Name <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="text" id="new_category_name" class="form-control">
              </div>
            </div>

            <div class="row">
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="The payment amount for this category">
                  Rate <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="number" step="any" id="new_category_rate" class="form-control">
              </div>
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Unit of measurement (e.g., per kg, per hour, per tree)">
                  Unit <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="text" id="new_category_unit" class="form-control">
              </div>
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Order in which this category appears in the list (starts with 0,1,2...)">
                  Display Order <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="number" id="new_category_order" class="form-control" value="0">
              </div>
            </div>
            <hr>

            <div class="row mb-2">
              <h6 class="mb-3">Condition (optional)</h6>
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Type of condition (e.g., weight, quantity, area, fruit)">
                  Condition Type <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="text" id="new_category_type" class="form-control" placeholder="e.g. weight, quantity, area">
              </div>
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Minimum value for this condition range">
                  Min Value <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="number" step="any" id="new_category_min" class="form-control">
              </div>
              <div class="col-md-4 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Maximum value for this condition range">
                  Max Value <i class="bi bi-info-circle text-muted ms-1"></i>
                </label>
                <input type="number" step="any" id="new_category_max" class="form-control">
              </div>
            </div>

            <div class="row mb-2">
              <div class="col-md-12 mb-2">
                <label class="form-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Unit for the condition values (e.g., kg, pcs, m²)">
                  Condition Unit <i class="bi bi-info-circle text-muted ms-1""></i>
                </label>
                <input type="text" id="new_category_cond_unit" class="form-control">
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" id="saveNewCategoryBtn" class="btn btn-success">Save Category</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
  `;
  $('body').append(modalHtml);

  $('#saveNewCategoryBtn').on('click', function () {
    const name = $('#new_category_name').val().trim();
    const key = name.toLowerCase().replace(/\s+/g, '_');
    const rate = $('#new_category_rate').val();
    const unit = $('#new_category_unit').val().trim();
    const order = parseInt($('#new_category_order').val()) || 0;
    const type = $('#new_category_type').val().trim();
    const min = $('#new_category_min').val();
    const max = $('#new_category_max').val();
    const condUnit = $('#new_category_cond_unit').val().trim();

    // Validate: if min or max is provided, type must not be empty
    const hasMinOrMax = (min !== "" && min !== null && typeof min !== 'undefined') ||
      (max !== "" && max !== null && typeof max !== 'undefined');

    if (hasMinOrMax && !type) {
      Swal.fire({
        icon: 'error',
        title: 'Validation Error',
        text: 'Condition Type is required when Min or Max values are provided. Please specify the type (e.g., weight, quantity, area).',
        confirmButtonText: 'OK'
      });
      return; // Stop processing
    }

    let conditions = null;
    if (type) {
      const c = {};
      if (min !== "") {
        const p = parseFloat(min);
        if (!Number.isNaN(p)) c[`min_${type}`] = p;
      }
      if (max !== "") {
        const p2 = parseFloat(max);
        if (!Number.isNaN(p2)) c[`max_${type}`] = p2;
      }
      if (condUnit) c.unit = condUnit;
      if (Object.keys(c).length > 0) conditions = c;
    }

    const newCat = {
      id: null,
      category_name: name,
      category_key: key,
      rate: rate,
      unit: unit,
      display_order: order,
      conditions: conditions
    };

    // callback stored on modal element
    const cb = $('#addCategoryModal').data('callback');
    if (typeof cb === 'function') cb(newCat);

    // reset & hide
    $('#addCategoryForm')[0].reset();
    const modalEl = document.getElementById('addCategoryModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
  });
}

/* Helper: open modal and provide callback */
function openAddCategoryModal(callback) {
  ensureAddCategoryModalExists();
  $('#addCategoryModal').data('callback', callback);
  const modal = new bootstrap.Modal(document.getElementById('addCategoryModal'));
  modal.show();

  // Initialize tooltips in the modal after it's shown
  $('#addCategoryModal').on('shown.bs.modal', function () {
    $(this).find('[data-bs-toggle="tooltip"]').each(function () {
      new bootstrap.Tooltip(this, {
        trigger: 'hover'
      });
    });
  });
}

/* Helper: append new category block to DOM using the exact same structure as renderTaskEditor */
function appendNewCategoryBlock(c) {
  // create a category-block HTML that matches the original structure and classes
  const cond = c.conditions || {};
  let condType = '';
  for (const k of Object.keys(cond)) {
    if (k.startsWith('min_')) { condType = k.replace(/^min_/, ''); break; }
    if (k.startsWith('max_')) { condType = k.replace(/^max_/, ''); break; }
  }
  const minVal = condType ? (cond[`min_${condType}`] ?? '') : '';
  const maxVal = condType ? (cond[`max_${condType}`] ?? '') : '';
  const condUnit = cond.unit ?? (c.unit || '');

  const idx = $('#workSection .task-editor .card-body .category-block').length;
  const block = `
    <div class="border rounded p-3 mb-3 category-block" data-index="${idx}" data-category='${JSON.stringify(c)}'>
      <div class="mb-2 small text-muted">
        <strong>Category ID:</strong> ${c.id || 'N/A'}
      </div>

      <!-- Row 0: Category Name -->
      <div class="row">
        <div class="col-md-10 mb-2">
          <label class="form-label">Category Name</label>
          <input type="text" class="form-control category-name" value="${c.category_name || ''}">
        </div>
        <div class="col-md-2 mb-2 d-flex align-items-end">
          <button class="btn btn-sm btn-danger remove-category-btn w-100" type="button" title="Remove category">
            <i class="bi bi-trash"></i> Remove
          </button>
        </div>
      </div>

      <!-- Row 1: Rate and Unit -->
      <div class="row">
        <div class="col-md-6 mb-2">
          <label class="form-label">Rate</label>
          <input type="number" class="form-control category-rate" value="${c.rate ?? ''}">
        </div>
        <div class="col-md-6 mb-2">
          <label class="form-label">Unit</label>
          <input type="text" class="form-control category-unit" value="${c.unit ?? ''}">
        </div>
      </div>

      <div class="row">
        <div class="col-md-3 mb-2">
          <label class="form-label">Type</label>
          <input type="text" class="form-control category-type" value="${condType || ''}">
        </div>
        <div class="col-md-3 mb-2">
          <label class="form-label">Min Value</label>
          <input type="number" class="form-control category-min" value="${minVal}">
        </div>
        <div class="col-md-3 mb-2">
          <label class="form-label">Max Value</label>
          <input type="number" class="form-control category-max" value="${maxVal}">
        </div>
        <div class="col-md-3 mb-2">
          <label class="form-label">Condition Unit</label>
          <input type="text" class="form-control category-condition-unit" value="${condUnit}">
        </div>
      </div>

      <div class="row">
        <div class="col-md-4 mb-2">
          <label class="form-label">Display Order</label>
          <input type="number" class="form-control category-order" value="${c.display_order ?? 0}">
        </div>
      </div>
    </div>
  `;
  // append to the categories container used in renderTaskEditor
  $('#workSection .task-editor .card-body').find('.mb-3').last().after(block);
}

/* -------------------- Add Payment Rate Modal -------------------- */
function ensureAddPaymentRateModalExists() {
  if ($('#addPaymentRateModal').length) return;

  const modalHtml = `
  <div class="modal fade" id="addPaymentRateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title fw-semibold">Add New Payment Rate</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
          <form id="createPaymentRateModalForm">
            <div class="mb-3">
              <label class="form-label fw-semibold">Task Name *:</label>
              <input type="text" id="modal_task_name" class="form-control" placeholder="Insert task name.." required>
            </div>

            <div class="mb-3">
              <label class="form-label fw-semibold">Description:</label>
              <textarea id="modal_description" class="form-control" placeholder="Insert description (optional).."></textarea>
            </div>

            <hr>

            <div class="d-flex justify-content-between align-items-center mb-3">
              <h6 class="mb-0 fw-bold">Payment Rate Categories</h6>
              <button type="button" class="btn btn-sm btn-success" id="modalAddCategoryBtn">
                <i class="bi bi-plus-circle"></i> Add Category
              </button>
            </div>

            <div id="modalCategorySection">
              <!-- Default Category 1 -->
              <div class="modal-category-card card mb-3">
                <div class="card-body">
                  <div class="d-flex justify-content-between align-items-center mb-2">
                    <h6 class="modal-category-title mb-0"><strong>Category 1</strong></h6>
                  </div>

                  <div class="mb-3">
                    <label class="form-label fw-semibold">Category Name *:</label>
                    <input type="text" class="form-control m-category-name" placeholder="e.g. Normal Pruning" required>
                  </div>

                  <div class="row mb-3">
                    <div class="col-md-6">
                      <label class="form-label fw-semibold">Rate (RM) *:</label>
                      <input type="number" step="any" class="form-control m-category-rate" placeholder="e.g. 4.00" required>
                    </div>
                    <div class="col-md-6">
                      <label class="form-label fw-semibold">Unit *:</label>
                      <input type="text" class="form-control m-category-unit" placeholder="per palm" required>
                    </div>
                  </div>

                  <hr>
                  <h6 class="mb-2">Condition (optional)</h6>
                  <div class="row">
                    <div class="col-md-3 mb-2">
                      <label class="form-label small">Type</label>
                      <input type="text" class="form-control m-condition-type" placeholder="e.g. weight">
                    </div>
                    <div class="col-md-3 mb-2">
                      <label class="form-label small">Min</label>
                      <input type="number" class="form-control m-condition-min" placeholder="0">
                    </div>
                    <div class="col-md-3 mb-2">
                      <label class="form-label small">Max</label>
                      <input type="number" class="form-control m-condition-max" placeholder="30">
                    </div>
                    <div class="col-md-3 mb-2">
                      <label class="form-label small">Unit</label>
                      <input type="text" class="form-control m-condition-unit" placeholder="kg">
                    </div>
                  </div>
                  <div class="row mt-2">
                    <div class="col-md-12">
                      <label class="form-label small">Display Order</label>
                      <input type="number" class="form-control m-category-order" value="0">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" id="submitCreateRateBtn" class="btn btn-success">Create Payment Rate</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </div>
    </div>
  </div>
  `;

  $('body').append(modalHtml);

  // Wire modal Category Add
  $('#modalAddCategoryBtn').on('click', function () {
    const categoryCount = $('.modal-category-card').length + 1;
    const cardHtml = `
      <div class="modal-category-card card mb-3">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="modal-category-title mb-0"><strong>Category ${categoryCount}</strong></h6>
            <button type="button" class="btn btn-sm btn-danger remove-modal-category-btn">
              <i class="bi-trash"></i> Remove
            </button>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Category Name *:</label>
            <input type="text" class="form-control m-category-name" placeholder="e.g. Normal Pruning" required>
          </div>

          <div class="row mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Rate (RM) *:</label>
              <input type="number" step="any" class="form-control m-category-rate" placeholder="e.g. 4.00" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Unit *:</label>
              <input type="text" class="form-control m-category-unit" placeholder="per palm" required>
            </div>
          </div>

          <hr>
          <h6 class="mb-2">Condition (optional)</h6>
          <div class="row">
            <div class="col-md-3 mb-2">
              <label class="form-label small">Type</label>
              <input type="text" class="form-control m-condition-type" placeholder="e.g. weight">
            </div>
            <div class="col-md-3 mb-2">
              <label class="form-label small">Min</label>
              <input type="number" class="form-control m-condition-min" placeholder="0">
            </div>
            <div class="col-md-3 mb-2">
              <label class="form-label small">Max</label>
              <input type="number" class="form-control m-condition-max" placeholder="30">
            </div>
            <div class="col-md-3 mb-2">
              <label class="form-label small">Unit</label>
              <input type="text" class="form-control m-condition-unit" placeholder="kg">
            </div>
          </div>
          <div class="row mt-2">
            <div class="col-md-12">
              <label class="form-label small">Display Order</label>
              <input type="number" class="form-control m-category-order" value="${categoryCount - 1}">
            </div>
          </div>
        </div>
      </div>
    `;
    $('#modalCategorySection').append(cardHtml);
  });

  // Wire modal Category Remove
  $('#modalCategorySection').on('click', '.remove-modal-category-btn', function () {
    $(this).closest('.modal-category-card').remove();
    // Re-label
    $('.modal-category-card').each(function (idx) {
      $(this).find('.modal-category-title strong').text(`Category ${idx + 1}`);
    });
  });

  // Wire Modal Submit
  $('#submitCreateRateBtn').on('click', async function () {
    const taskName = $('#modal_task_name').val().trim();
    const desc = $('#modal_description').val().trim();

    if (!taskName) {
      Swal.fire({ icon: 'warning', text: 'Task Name is required.' });
      return;
    }

    const categories = [];
    let isValid = true;
    const errors = [];

    $('.modal-category-card').each(function (idx) {
      const catName = $(this).find('.m-category-name').val().trim();
      const rateVal = $(this).find('.m-category-rate').val();
      const unitVal = $(this).find('.m-category-unit').val().trim();
      const orderVal = parseInt($(this).find('.m-category-order').val()) || 0;

      if (!catName || !rateVal || !unitVal) {
        isValid = false;
        errors.push(`Category ${idx + 1} is missing required fields (Name, Rate, or Unit).`);
        return;
      }

      const type = $(this).find('.m-condition-type').val().trim();
      const minVal = $(this).find('.m-condition-min').val();
      const maxVal = $(this).find('.m-condition-max').val();
      const condUnit = $(this).find('.m-condition-unit').val().trim();

      const hasMinOrMax = (minVal !== "" && minVal !== null && typeof minVal !== 'undefined') ||
        (maxVal !== "" && maxVal !== null && typeof maxVal !== 'undefined');

      if (hasMinOrMax && !type) {
        isValid = false;
        errors.push(`Category ${idx + 1} has min/max values but no Condition Type specified.`);
        return;
      }

      let conditions = null;
      if (type) {
        const c = {};
        if (minVal !== "") {
          const parsed = parseFloat(minVal);
          if (!Number.isNaN(parsed)) c[`min_${type}`] = parsed;
        }
        if (maxVal !== "") {
          const parsed2 = parseFloat(maxVal);
          if (!Number.isNaN(parsed2)) c[`max_${type}`] = parsed2;
        }
        if (condUnit) c.unit = condUnit;
        if (Object.keys(c).length > 0) conditions = c;
      }

      categories.push({
        category_name: catName,
        category_key: catName.toLowerCase().replace(/\s+/g, '_'),
        rate: parseFloat(rateVal),
        unit: unitVal,
        display_order: orderVal,
        conditions: conditions
      });
    });

    if (categories.length === 0) {
      isValid = false;
      errors.push("You must define at least one category.");
    }

    if (!isValid) {
      Swal.fire({
        icon: 'error',
        title: 'Validation Error',
        html: `<ul class="text-start">${errors.map(e => `<li>${e}</li>`).join('')}</ul>`
      });
      return;
    }

    const token = getToken();
    if (!token) return;

    const bodyData = {
      task_name: taskName,
      description: desc,
      categories: categories
    };

    try {
      const res = await fetch(PAYMENT_RATES_API_URL, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Accept": "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(bodyData)
      });

      const json = await res.json();

      if (json.success) {
        Swal.fire({
          icon: "success",
          title: "Payment Rate Created!",
          text: "The task rate and its categories have been added.",
          timer: 2000,
          showConfirmButton: false
        });
        
        // Reset form & close modal
        $('#createPaymentRateModalForm')[0].reset();
        $('#modalCategorySection').html(`
          <div class="modal-category-card card mb-3">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <h6 class="modal-category-title mb-0"><strong>Category 1</strong></h6>
              </div>
              <div class="mb-3">
                <label class="form-label fw-semibold">Category Name *:</label>
                <input type="text" class="form-control m-category-name" placeholder="e.g. Normal Pruning" required>
              </div>
              <div class="row mb-3">
                <div class="col-md-6">
                  <label class="form-label fw-semibold">Rate (RM) *:</label>
                  <input type="number" step="any" class="form-control m-category-rate" placeholder="e.g. 4.00" required>
                </div>
                <div class="col-md-6">
                  <label class="form-label fw-semibold">Unit *:</label>
                  <input type="text" class="form-control m-category-unit" placeholder="per palm" required>
                </div>
              </div>
              <hr>
              <h6 class="mb-2">Condition (optional)</h6>
              <div class="row">
                <div class="col-md-3 mb-2">
                  <label class="form-label small">Type</label>
                  <input type="text" class="form-control m-condition-type" placeholder="e.g. weight">
                </div>
                <div class="col-md-3 mb-2">
                  <label class="form-label small">Min</label>
                  <input type="number" class="form-control m-condition-min" placeholder="0">
                </div>
                <div class="col-md-3 mb-2">
                  <label class="form-label small">Max</label>
                  <input type="number" class="form-control m-condition-max" placeholder="30">
                </div>
                <div class="col-md-3 mb-2">
                  <label class="form-label small">Unit</label>
                  <input type="text" class="form-control m-condition-unit" placeholder="kg">
                </div>
              </div>
              <div class="row mt-2">
                <div class="col-md-12">
                  <label class="form-label small">Display Order</label>
                  <input type="number" class="form-control m-category-order" value="0">
                </div>
              </div>
            </div>
          </div>
        `);
        
        const modalEl = document.getElementById('addPaymentRateModal');
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();

        getPaymentRates(); // Refresh Task List
      } else {
        Swal.fire({
          icon: "warning",
          title: "Failed to create",
          text: json.message
        });
      }
    } catch (err) {
      console.error("Error creating payment rate:", err);
      Swal.fire({ icon: 'error', text: 'An unexpected error occurred.' });
    }
  });
}

function openAddPaymentRateModal() {
  ensureAddPaymentRateModalExists();
  const modal = new bootstrap.Modal(document.getElementById('addPaymentRateModal'));
  modal.show();
}

// Bind the Add new Payment Rate button click
$(document).ready(function () {
  $('body').on('click', '#openAddRateModalBtn', function () {
    openAddPaymentRateModal();
  });
});

